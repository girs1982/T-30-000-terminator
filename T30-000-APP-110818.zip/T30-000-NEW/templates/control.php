<?php use PiPHP\GPIO\GPIO; use PiPHP\GPIO\Pin\PinInterface; // Retrieve pin 18 and configure it as an output pin if(isset($_POST['submit'])) { echo 'huuy'; ///$command = escapeshellcmd('python /var/www/html/python/pydetect.py'); 
///$output = shell_exec($command); ///echo $output; ////echo shell_exec("python /var/www/html/python/pynotdetect.py 2>&1"); echo'huilka';
}
if(isset($_POST['submit22'])) { echo 'huuy2'; echo shell_exec("ls");
}
if(isset($_POST['vniz'])) { echo 'vniz'; /////echo shell_exec("ls"); echo shell_exec("sudo gpio -g write 17 0"); echo shell_exec("sudo gpio -g write 18 1"); echo shell_exec("sudo gpio -g write 27 0"); echo shell_exec("sudo gpio 
-g write 23 1");
}
if(isset($_POST['vverh'])) { echo 'vverh'; echo shell_exec("sudo gpio -g write 17 1"); echo shell_exec("sudo gpio -g write 18 0"); echo shell_exec("sudo gpio -g write 27 1"); echo shell_exec("sudo gpio -g write 23 0"); /////echo 
shell_exec("ls");
}
if(isset($_POST['vlevo'])) { echo 'vlevo'; echo shell_exec("sudo gpio -g write 17 0"); echo shell_exec("sudo gpio -g write 18 1"); echo shell_exec("sudo gpio -g write 27 1"); echo shell_exec("sudo gpio -g write 23 0"); /////echo 
shell_exec("ls");
}
if(isset($_POST['vpravo'])) { echo 'vpravo'; /////echo shell_exec("ls"); echo shell_exec("sudo gpio -g write 27 0"); echo shell_exec("sudo gpio -g write 23 1"); echo shell_exec("sudo gpio -g write 17 1"); echo shell_exec("sudo 
gpio -g write 18 0");
}
if(isset($_POST['stop'])) { echo 'stop'; echo shell_exec("sudo gpio -g write 17 0"); echo shell_exec("sudo gpio -g write 18 0"); echo shell_exec("sudo gpio -g write 27 0"); echo shell_exec("sudo gpio -g write 23 0"); /////echo 
shell_exec("ls");
}
?>
